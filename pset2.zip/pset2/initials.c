#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

//check50 2014.fall.pset2.initials initials.c

int main(void)
{
    string s = GetString();
    printf("%c", toupper(s[0]));
    //get name from user
    //get first character from each word, print it.
    //space is 32 in ASCII
    for (int i = 0, n = strlen(s); i<n; i++)
    {
        //checking for space
        if (s[i] == 32)
        {
        //print next character after space, and capitalize
        printf("%c", toupper(s[i+1]));
        }
    }
    printf("\n");
}
