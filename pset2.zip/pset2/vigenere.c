#include <stdio.h>
#include <cs50.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

//check50 2014.fall.pset2.vigenere vigenere.c

//Usage: ./vigenere key

int main(int argc, string argv[])
{
    //making sure there are two arguments total
    if (argc != 2)
    {
        printf("Usage: ./vigenere key\n");
        return 1;
    }
    else
    {
        string a = argv[1];
        //checking to see if all in string are characters
        for (int i = 0, n = strlen(a); i < n; i++)
        {
            if (isalpha(a[i]) == false)
            {
                printf("You can only put alphabetical characters in your keyword!\n");
                return 1;
            }
        }
        string b = GetString();
        int m = strlen(a);
        for (int i = 0, n = strlen(b), j = 0; i < n; i++)
        {
            if (isalpha(b[i]))
            {   
                //for capitals
                if (b[i] >= 'A' && b[i] <= 'Z')
                {
                    //a[j%m]-'A' is the shift. finds letter in arg. subtracts A to find shift.
                    //if greater than ], then will modulo back to A by adding modulo to A.
                    if (b[i]+(toupper(a[j%m])-'A') > 'Z')
                    {
                        printf("%c", ((b[i]+(toupper(a[j%m])-'A'))%'[')+'A');
                        j++;
                    }
                    else
                    {
                        printf("%c", b[i]+(toupper(a[j%m])-'A'));
                        j++;
                    }
               
      
                 }
                 //lowercase
                 else if (b[i] >= 'a' && b[i] <= 'z')
                 {
                    if (b[i]+(tolower(a[j%m])-'a') > 'z')
                    {
                        printf("%c", ((b[i]+(tolower(a[j%m])-'a'))%123)+'a');
                        j++;
                    }
                    else
                    {
                        printf("%c", b[i]+(tolower(a[j%m])-'a'));
                        j++;
                    }
               
      
                 }
            }
            //if not character, don't do anything
            else
            {
                printf("%c", b[i]);
            }
    
        }
    }
    printf("\n");
}
