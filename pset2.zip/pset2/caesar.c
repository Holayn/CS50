#include <stdio.h>
#include <cs50.h>
#include <stdlib.h>
#include <string.h>

//check50 2014.fall.pset2.caesar caesar.c

//Usage: ./caesar key

int main(int argc, string argv[])
{
    //takes argument and puts it into a string
    if (argc != 2)
    {
        printf("Usage: ./caesar key\n");
        return 1;
    }
    else
    {
        //converting string to integer
        int k = atoi(argv[1]);
        //if k is greater than 26
        k = k%26;
        string s = GetString();
        for (int i = 0, n = strlen(s); i < n; i++)
        {
            //for uppercase
            if (s[i] >= 'A' && s[i] <= 'Z')
            {
                //if sum greater than 'Z', find remainder, add it to 'A'
                if (s[i]+k > 90)
                {
                    printf("%c", ((s[i]+k) % 90)+64);
                }
                else
                {
                    printf("%c", (s[i]+k));
                }
            }
            //for lowercase
            else if (s[i] >= 'a' && s[i] <= 'z')
            {
                //if sum greater than 'z', find remainder, add it to 'a'
                if (s[i]+k > 122)
                {
                printf("%c", ((s[i]+k) % 122)+96);
                }
                else
                {
                    printf("%c", (s[i]+k));
                }
            }
            //dealing with symbols such as !, , , . , etc
            else
            {
                printf("%c", s[i]);
            }
        }
        printf("\n");
        return 0;
    }
}
