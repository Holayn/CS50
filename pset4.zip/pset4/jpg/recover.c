/**
 * recover.c
 *
 * Computer Science 50
 * Problem Set 4
 *
 * Recovers JPEGs from a forensic image.
 */
#include <stdio.h>
#include <cs50.h>
#include <stdlib.h>
#include <stdint.h>

int main(int argc, char* argv[])
{
    //keeping track of images found
    int imagecount = 0;
    //storage for bytes to be read
    uint8_t buffer[512];
    //declaring img
    FILE* img = NULL;
    //declaring file name, type char, size of 20
    char title[20];
    FILE* file = fopen("card.raw", "r");
    //FILE* fileout = fopen(
    //doing this until end of card
    while(fread(&buffer,512,1,file)==1)
    //while(true)
    {
        //char c = fgetc(file);
        //if(feof(file))
        //    break;
        //reading 512 bytes from file into buffer
        //fread(&buffer,512,1,file);
        //finding start of jpg
        if ((buffer[0] == 0xff && buffer[1] == 0xd8 && buffer[2] == 0xff && buffer[3] == 0xe0) || (buffer[0] == 0xff && buffer[1] == 0xd8 && buffer[2] == 0xff && buffer[3] == 0xe1))
        {    
            if (imagecount == 0)
            {
                sprintf(title, "%.3d.jpg", imagecount);
                img = fopen(title, "w");
            }
            else if (imagecount > 0)
            {
                fclose(img);
                sprintf(title, "%.3d.jpg", imagecount);
                img = fopen(title, "w");
            }
            imagecount = imagecount + 1;
        }
        if (img != NULL)
        {
            fwrite(&buffer,512,1,img);
        }
        
            
    }
    //closing everything
    fclose(img);
    fclose(file);
    return 0;
    
}
