#include <stdio.h>
int main(void){
    int integer = 10;
    printf("%.3d\n", integer);
}
