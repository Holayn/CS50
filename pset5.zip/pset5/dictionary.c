/****************************************************************************
 * dictionary.c
 *
 * Computer Science 50
 * Problem Set 5
 *
 * Implements a dictionary's functionality.
 ***************************************************************************/

#include <stdbool.h>

#include "dictionary.h"
#include <stdio.h>
#include <cs50.h>
#include <stdlib.h>
#include <stdint.h>

/**
 * Returns true if word is in dictionary else false.
 */
bool check(const char* word)
{
    // TODO
    return false;
}

/**
 * Loads dictionary into memory.  Returns true if successful else false.
 */
bool load(const char* dictionary)
{
    // TODO
    //making a trie
    int index;
    typedef struct node
    {
        bool is_word;
        struct node* children[28];
    }
    node;
    //pointer to root of trie
    node* root;
    root = malloc(sizeof(node));
    //open dictionary
    FILE* words = fopen(dictionary, "r");
    //put pointer over each character in dictionary one by one
    for (int c = fgetc(words); c != EOF; c = fgetc(words))
    {
        //if pointer is over a character
        if (isalpha(c))
        {
            index = c - "a";
            //put letter in that array
            children[index] = c;
            //now need to make a new array
            
        }
        //if pointer is over a '
        else if (c == "'")
        {
            //store at end of array
            index = c - 12;
            children[index] = c;
        }
        //if pointer over new line thing
        else if (c == "\")
        {
            //set is_word to true
            //put pointer back to root of trie
            is_word = true;
            //need to skip over n in \n
            fseek(words, 1, SEEK_CUR);
            
        }
        
    }
    return true;
}

/**
 * Returns number of words in dictionary if loaded else 0 if not yet loaded.
 */
unsigned int size(void)
{
    // TODO
    return 0;
}

/**
 * Unloads dictionary from memory.  Returns true if successful else false.
 */
bool unload(void)
{
    // TODO
    return false;
}
