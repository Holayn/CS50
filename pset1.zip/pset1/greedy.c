#include <cs50.h>
#include <stdio.h>
#include <math.h>
/** this program calculates the least amount of coins that can be given back as change **/
int main(void)
{
    float money_owed;
    
    //waits for valid input from user
    do
    {
        printf("What change do you owe? ");
        money_owed = GetFloat();
    }
    while (money_owed < 0);
    
    //converting to cents
    money_owed = money_owed*100;
    
    //money_total is money owed converted to cents
    int money_total = round(money_owed);
   
    //for quarters. this shows money left after quarters are used.
    int money_left_quarters = money_total % 25; 
    
    //finding how many quarters were used
    int quarters = (money_total - money_left_quarters)/25;
  
    //for dimes. how much money left after dimes used
    int money_left_dimes = money_left_quarters % 10;
    
    //finding how many dimes were used
    int dimes = (money_left_quarters - money_left_dimes)/10;
    
    //for nickels. how much money left after nickels used
    int money_left_nickels = money_left_dimes % 5;
    
    //finding how many nickels were used
    int nickels = (money_left_dimes - money_left_nickels)/5;
    
    //for pennies, just equal to money_left_nickels
    int pennies = money_left_nickels;
    
    //adds up all the amount of coins to find total coins used
    int total_coins = quarters + dimes + nickels + pennies;
    
    printf("%i\n",total_coins);
    



}
