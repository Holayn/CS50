#include <stdio.h>
#include <cs50.h>
/** this code creates a right-aligned half-pyramid corresponding to user input**/


int main(void)
{
    //making a continuous prompt until input is valid
    int height;
    do
    {
        printf("Give me the height of a half-pyramid no greater than 23: ");
        height = GetInt();
    }
    while (height < 0 || height > 23);
    // number of spaces corresponds to height - 1
    // number of hashes corresponds to row + 2

    // first row is considered row 0
    int row = 0;
    
    // number of spaces determined by height entered
    int spaces = height - 1;
    
    // this repeats process *height* times
    for (int i = 0; i < height; i++)
    {
        // print spaces corresponding to height entered
        for (int i = 0; i < spaces; i++)
        {
        printf(" ");
        }
        
        // then print hashes corresponding to row number
        for (int i = 0; i < row + 2; i++)
        {
        printf("#");
        }
        
        // so that an additional # is printed
        row = row + 1;
        
        //so that one less space is printed
        spaces = spaces - 1;
        
        // starting a new line
        printf("\n");
        
            
 
    }


}
