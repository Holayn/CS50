/**
 * helpers.c
 *
 * Computer Science 50
 * Problem Set 3
 *
 * Helper functions for Problem Set 3.
 */
       
#include <cs50.h>
#include <stdio.h>
#include "helpers.h"
#include <math.h>

/**
 * Returns true if value is in array of n values, else false.
 */

/*for (int i = 0; i < n; i++)
    {
        if (values[i] == value)
        {
            return true;
        }
        
    }
    //}
    return false;*/

bool search(int value, int values[], int n)
{
    int min = 0;
    int max = n-1;
    for (int i = 0; i < n; i++)
    {
        int midpt = (min+max)/2;
        if (values[midpt] < value)
        {
            min = midpt;
        }
        else if (values[midpt] > value)
        {
            max = midpt;
        }
        
        else if (values[midpt] == value)
        {
            return true;
        }
    }
    return false;
}

/*
 * Sorts array of n values.
 */
void sort(int values[], int n)
{
    //checking over every number in list
    for (int i = 0; i < (n-1); i++)
    {
        int min = values[i];
        //checking with next number, see if smaller
        for (int j = (i+1); j < n; j++)
        {
            if (values[j] < min)
            {
                min = values[j];
            }
            //swapping values
            if (min != values[i])
            {
                values[j] = values[i];
                values[i] = min;
            }
        }
    }
    //code I used to see if my sorting worked.
    for (int m = 0; m < n; m++)
    {
        printf("%d ", values[m]);
    }
    return;
    //don't need to return anything, because c is editing array, didn't make copy of array
}
